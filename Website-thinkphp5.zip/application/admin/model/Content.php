<?php

namespace app\admin\model;

use think\Model;

class Content extends Model
{
    protected $table = "content";
}
