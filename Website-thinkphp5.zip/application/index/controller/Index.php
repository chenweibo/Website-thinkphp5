<?php
namespace app\index\controller;

class Index
{
    public function index()
    {
        //  $toemail='563960993@qq.com';
        // $name='bbx';
        // $subject='感谢你注册我们的网站';
        // $content='恭喜你，出册成功。';
        // send_mail($toemail,$name,$subject,$content)
        return "hello word";
    }
}
